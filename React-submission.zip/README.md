## Notes App

A simple notes app, design inspired by google keep

Feature :

- Add notes
- Set archive/active notes
- Search notes

Library used :

- React
- Toastify (Notification)
- Fontawesome (Icons)
