const getCurrentDate = () => {
  return +new Date();
};

export default getCurrentDate;
